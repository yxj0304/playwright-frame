# Author: Cys

import asyncio
import allure
import time
import requests
import pytest
from playwright.sync_api import sync_playwright
from playwright.async_api import async_playwright
import tabula
import pandas as pd
import csv


class TestDemo:
    playwright = None
    browser = None
    fileList = []

    @classmethod
    def setup_class(cls):
        cls.playwright = sync_playwright().start()
        for browser_type in [cls.playwright.chromium]:
            cls.browser = browser_type.launch(channel="msedge", headless=False, args=['--start-maximized'],
                                              downloads_path="C:\\tmp")
            cls.context = cls.browser.new_context(no_viewport=True)

    @allure.step("抓数据")
    @pytest.mark.first
    def test_getData(cls):
        cls.page = cls.context.new_page()
        cls.page.goto(url="https://datas.p5w.net/fullText/301236",timeout=55000)
        cls.page.wait_for_load_state("networkidle")

        contentTableRows = "xpath=//article//div[contains(@class,'body-wrapper')]//tbody/tr"
        countOfRows = cls.page.locator(contentTableRows).count()
        print(countOfRows)
        countOfWait = 6;
        while (countOfRows == 0 and countOfWait > 0):
            time.sleep(6)
            countOfWait = countOfWait - 1

        if (countOfRows > 0):
            for i in range(1, countOfRows + 1):
                name = contentTableRows + "[" + str(i) + "]/td[1]/div[@class='cell']"
                with cls.context.expect_page() as new_page_info:
                    cls.page.click(name)
                new_page = new_page_info.value

                print("downloading")
                downloadedfile = requests.get(new_page.url)
                open("C:\\tmp\\" + cls.page.text_content(name) + ".pdf", 'wb').write(downloadedfile.content)
                cls.fileList.append(cls.page.text_content(name) + ".pdf")

        else:
            print("无文件")

    @allure.step("分析数据")
    @pytest.mark.second
    def test_analyzeData(cls):
        # tabula.environment_info()
        for file in cls.fileList:
            read_path = "C:\\tmp\\" + file
            tables = tabula.read_pdf(read_path, pages="all", multiple_tables=True)
            # print(type(tables))
            i = 0
            for item in tables:
              # print(item, type(item))
              if(str(item).__contains__("商誉")):
                item.to_csv(read_path.replace('.pdf','')+str(i)+'.csv',index = False)
                # print(item)
                for row in item.itertuples():
                    # if row.count()
                    if (row[1]=="商誉"):
                       print(row)
                       result=float(str(row[2]).replace(",",''))-float(str(row[3]).replace(",",''))
                       if (result>0):
                           print(str(file).replace(".pdf","")+row[1]+"增加")
                       elif(result==0):
                           print(str(file).replace(".pdf","")+row[1]+"不变")
                       else: print(str(file).replace(".pdf","")+row[1]+"减少")
                       break
                  # i = i+1
                break

    @classmethod
    def teardown_class(cls):
        cls.browser.close()
        cls.playwright.stop()
