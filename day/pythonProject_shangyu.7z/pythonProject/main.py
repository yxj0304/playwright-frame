import pytest, platform, os
from utilities.PathUtility import create_folder, delete_folder_and_sub_files, REPORTPATH, REPORT_XMLPATH, \
    ALLURECOMMANDLINEPATH_WINDOWS, ALLURECOMMANDLINEPATH_LINUX


if __name__ == '__main__':

    create_folder(REPORTPATH)
    delete_folder_and_sub_files(REPORT_XMLPATH)
    create_folder(REPORT_XMLPATH)

    # run test cases by path
    pytest.main(['-s', '-v', 'steps/Test_GetData.py', '--alluredir', r'report/xml'])
    # run test cases by tags
    # pytest.main(['-m', 'debug', '-s', '-v', 'steps/', '--alluredir', r'report/xml'])

    if platform.system() == 'Windows':
        command = "{} generate report/xml -o report/allure_report --clean".format(ALLURECOMMANDLINEPATH_WINDOWS)
    else:
        command = "{} generate report/xml -o report/allure_report --clean".format(ALLURECOMMANDLINEPATH_LINUX)

    os.system(command=command)


# See PyCharm help at https://www.jetbrains.com/help/pycharm/
