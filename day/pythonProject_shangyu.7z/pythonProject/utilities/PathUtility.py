import os
import shutil

BASEDIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BROWSER_CHROME = os.path.join(BASEDIR, 'driver/chromedriver')
REPORTPATH = os.path.join(BASEDIR, 'report')
ALLURECOMMANDLINEPATH_LINUX = os.path.join(BASEDIR, 'libraries/allure-commandline/dist/bin/allure')
ALLURECOMMANDLINEPATH_WINDOWS = os.path.join(BASEDIR, 'libraries/allure-commandline/dist/bin/allure.bat')
REPORT_XMLPATH = os.path.join(REPORTPATH, 'xml')


def create_folder(path):
    if not os.path.exists(path):
        os.mkdir(path)


def delete_folder_and_sub_files(path):
    if os.path.exists(path):
        shutil.rmtree(path)